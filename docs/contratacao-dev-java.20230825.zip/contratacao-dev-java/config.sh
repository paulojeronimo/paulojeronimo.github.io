URI_BASE=${URI_BASE:-https://paulojeronimo.com/docs}
CODE=${CODE:-20230825}
ZIP=$BASE_NAME.$CODE.zip
export PDF_NAME=$BASE_NAME.$CODE.pdf
