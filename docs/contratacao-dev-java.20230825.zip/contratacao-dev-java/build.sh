#!/usr/bin/env bash
set -eou pipefail
cd $(dirname $0)
BASE_NAME=$(basename $PWD)

source ./config.sh

commit=$(git rev-parse --short HEAD 2> /dev/null) || commit=SNAPSHOT

# https://gist.github.com/paulojeronimo/95977442a96c0c6571064d10c997d3f2 
GENERATE_PDF=${GENERATE_PDF:-true} docker-asciidoctor-builder \
    -a uri-doc=$URI_BASE/$ZIP \
    -a commit=$commit \
    -a code=$CODE \
    -a html-file=index.html \
    -a pdf-file=$PDF_NAME "$@"

cd ..
rm -f $BASE_NAME/build/$ZIP
zip -r $BASE_NAME/build/$ZIP $BASE_NAME/ \
  -x "$BASE_NAME/.git/*" \
  -x "$BASE_NAME/private/*" \
  -x "$BASE_NAME/build/$ZIP"
